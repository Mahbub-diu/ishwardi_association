<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SingleUpdate;
Use App\Models\Service;
Use App\Models\User;
use App\Http\Requests\StoreSingleUpdateRequest;
use App\Http\Requests\UpdateSingleUpdateRequest;
use Validator;
use Auth;
class SingleUpdateController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:news-event-list|news-event-create|news-event-edit|news-event-delete', ['only' => ['index','store']]);
         $this->middleware('permission:news-event-list', ['only' => ['index']]);
         $this->middleware('permission:news-event-create', ['only' => ['create','store']]);
         $this->middleware('permission:news-event-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:news-event-delete', ['only' => ['destroy']]);
    }
	
	/**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
		$service = Service::getList();
		 
        $data = SingleUpdate::orderBy('id','DESC')->paginate(10);
		
        return view('backend.single-updates.index',compact('data', 'service'))
            ->with('i', ($request->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
		$services = Service::getList();
        return view('backend.single-updates.create', compact('services'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
         $validator = Validator::make($request->all(), [
				'title' => 'required',
				'service_id' => 'required',
				'feature_image' => 'required|mimes:jpeg,png,jpg,webp',
				'news_short_details' => 'required',
				'news_full_details' => 'required',
			], 
            [
               'service_id.required' => 'Service is required',
            ])->validate();
    
        $input = $request->all();
		
		
		if ( !empty($input['feature_image']) ) 
		{
            
            $imagePath = $input['feature_image'];
			
            $imageName = 'single-updates_'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['feature_image']->storeAs('single-updates', $imageName, 'public');
         
            $input['feature_image'] = $imageName;
      
        }
		
		$images = [];
		
		if( !empty($input['image1']) )
		{
			$imagePath = $input['image1'];
			
			$imageName = 'single-updates_1'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
			$path = $imagePath->storeAs('single-updates', $imageName, 'public');
         
			$image1  = $imageName;
			
			$images[] = $image1;
			
		}
		
		if( !empty($input['image2']) )
		{
			$imagePath = $input['image2'];
			
			$imageName = 'single-updates_2'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
			$path = $imagePath->storeAs('single-updates', $imageName, 'public');
         
			$image2  = $imageName;
			
			$images[] = $image2;
			
		}
		
		if( !empty($input['image3']) )
		{
			$imagePath = $input['image1'];
			
			$imageName = 'single-updates_3'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
			$path = $imagePath->storeAs('single-updates', $imageName, 'public');
         
			$image3  = $imageName;
			
			$images[] = $image3;
			
		}
		
		//dd($images );
		
		
		
        $input['images'] = json_encode($images);
		
        SingleUpdate::create($input);
		
        return redirect()->route('single-updates.index')
                        ->with('success','Data added successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(SingleUpdate $singleUpdate)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SingleUpdate $singleUpdate)
    {
         $services = Service::getList();
		 $images = json_decode($singleUpdate->images);
		 
		 return view('backend.single-updates.edit',compact('images', 'singleUpdate','services'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(SingleUpdate $singleUpdate, Request $request)
    {
        
        
         $validator = Validator::make($request->all(), [
				'title' => 'required',
				'service_id' => 'required',
				'feature_image' => 'mimes:jpeg,png,jpg,webp',
				'news_short_details' => 'required',
				'news_full_details' => 'required',
			], 
            [
               'service_id.required' => 'Service is required',
            ])->validate();
       
        $input = $request->all();
        if ( empty($input['feature_showing'] ) )
		{
			$input['feature_showing'] = 0;
		}

		if ( !empty($input['feature_image']) ) 
		{
            
            $imagePath = $input['feature_image'];
			
            $imageName = 'single-updates_'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['feature_image']->storeAs('single-updates', $imageName, 'public');
         
            $input['feature_image'] = $imageName;
      
			if( file_exists('storage/app/public/single-updates/'.$singleUpdate->feature_image) ){
			
				unlink('storage/app/public/single-updates/'.$singleUpdate->feature_image);
			
			}
        }
		
		$prevImages = json_decode($singleUpdate->images);
		//dd($prevImages);
		
		$images = [];
		
		
		if ( !empty($input['image1']) ) {
            
            $imagePath = $input['image1'];
			
            $imageName = 'single-updates_1'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['image1']->storeAs('single-updates', $imageName, 'public');
         
            $images[] = $imageName;
      
			if( !empty($prevImages[0]) ){


                if( file_exists('storage/app/public/single-updates/'.$prevImages[0]) ){
                
                    unlink('storage/app/public/single-updates/'.$prevImages[0]);
                
                }
           }
        }
		
		
		if( !empty($input['image2']) )
		{
			$imagePath = $input['image2'];
			
			$imageName = 'single-updates_2'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
			$path = $imagePath->storeAs('single-updates', $imageName, 'public');
         
			$image2  = $imageName;
			
			$images[] = $image2;
			
			if( !empty($prevImages[1]) ){


                if( file_exists('storage/app/public/single-updates/'.$prevImages[1]) ){
                
                    unlink('storage/app/public/single-updates/'.$prevImages[1]);
                
                }
           }
		}
		
		
		if( !empty($input['image3']) )
		{
			$imagePath = $input['image3'];
			
			$imageName = 'single-updates_3'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
			$path = $imagePath->storeAs('single-updates', $imageName, 'public');
         
			$image3  = $imageName;
			
			$images[] = $image3;
			
			if( !empty($prevImages[2]) ){


                if( file_exists('storage/app/public/single-updates/'.$prevImages[2]) ){
                
                    unlink('storage/app/public/single-updates/'.$prevImages[2]);
                
                }
           }
			
		}
		
		
		//dd($images );
		
			
		
        $input['images'] = json_encode($images);

        $data = SingleUpdate::find( $singleUpdate->id );
        
        if( $data->update($input) ) {
            $responseStatus = 'success';
            $responseMessage = 'Updated successfully.';

        }else{
            $responseStatus = 'error';
            $responseMessage = 'Something went wrong, please try again.';
       
        }

        //$add = CompanyBrand::create(['name' => $request->input('name')]);
    
        return redirect()->route('single-updates.index')
                        ->with($responseStatus, $responseMessage);
						

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SingleUpdate $singleUpdate)
    {
		if( file_exists('storage/app/public/single-updates/'.$singleUpdate->image) ){
                
			//unlink('storage/app/public/single-updates/'.$singleUpdate->image);
		
		}
		
        SingleUpdate::find($singleUpdate->id)->delete();

        return response()->json(['success'=>'Data Deleted Successfully!']);
    }
	
	
	public function approve($id)
    {
		
		$statusValue = 0;
		
		$responseStatus = '';
		$responseMessage = '';
		
		
		$currentRoleName = User::find(Auth::user()->id)->getRoleNames()->first();
		//$roleInfo = $user;
		//dd($currentRoleName);
		
		if( $currentRoleName == 'Data Editor' )
		{
			$statusValue = 1;
			
		}else if( $currentRoleName == 'Admin' )
		{
			$statusValue = 3;
			
		}else if( $currentRoleName == 'Super Admin' ||  $currentRoleName == 'System Admin' )
		{
			$statusValue = 5;
			
		}
	   
		$data = SingleUpdate::find( $id );
		
		$input['status'] = $statusValue;

		if( $data->update($input) ) {
			$responseStatus = 'success';
            $responseMessage = 'Data Approved Successfully!';

        }else{
            $responseStatus = 'error';
            $responseMessage = 'Something went wrong, please try again.';
       
        }
		
		
        return response()->json([$responseStatus=>$responseMessage]);
    }
	
	
	public function cancel($id)
    {
		$statusValue = 0;
		
		$responseStatus = '';
		$responseMessage = '';
		
		
		$currentRoleName = User::find(Auth::user()->id)->getRoleNames()->first();
		//$roleInfo = $user;
		//dd($currentRoleName);
		
		if( $currentRoleName == 'Data Editor' )
		{
			$statusValue = 2;
			
		}else if( $currentRoleName == 'Admin' )
		{
			$statusValue = 4;
			
		}else if( $currentRoleName == 'Super Admin' ||  $currentRoleName == 'System Admin' )
		{
			$statusValue = 6;
			
		}
	   
		$data = SingleUpdate::find( $id );
		
		$input['status'] = $statusValue;

		if( $data->update($input) ) {
			$responseStatus = 'success';
            $responseMessage = 'Data Cancled Successfully!';

        }else{
            $responseStatus = 'error';
            $responseMessage = 'Something went wrong, please try again.';
       
        }
		
		
        return response()->json([$responseStatus=>$responseMessage]);
    }
	
}
