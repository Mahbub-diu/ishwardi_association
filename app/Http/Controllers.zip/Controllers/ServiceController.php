<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Http\Requests\StoreServiceRequest;
use App\Http\Requests\UpdateServiceRequest;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    
	function __construct()
    {
         $this->middleware('permission:service-list|service-create|service-edit|service-delete', ['only' => ['index','store']]);
         $this->middleware('permission:service-create', ['only' => ['create','store']]);
         $this->middleware('permission:service-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:service-delete', ['only' => ['destroy']]);
    }
	
	
	/**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        
		$data = Service::paginate(10);
		
		if($request->ajax()){
			
			return view('backend.services.index-pagination',['data'=>$data]); 
       
        }
		
        return view('backend.services.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreServiceRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Service $service)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Service $service)
    {
		return view('backend.services.edit',compact('service'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Service $service)
    {
        $input = $request->all();
        
        $this->validate($request, [
				'short_description' => 'required',
				'icon' => 'mimes:jpeg,png,jpg,gif,webp|dimensions:width=385,height=260'
			]);

       
        $input = $request->all();
        $input['updated_at'] = date("Y-m-d h:i:sa");;

		
		if ( !empty($input['icon']) ) {
            
            $imagePath = $input['icon'];
			
            $imageName = 'service_'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['icon']->storeAs('services', $imageName, 'public');
         
            $input['icon'] = $imageName;
			
			if( !empty($service->icon) ){


                if( file_exists('storage/app/public/services/'.$service->icon) ){
                
                    unlink('storage/app/public/services/'.$service->icon);
                
                }
           }
      
        }
		
       

        $data = Service::find( $service->id );
        
        if( $data->update($input) ) {
            $responseStatus = 'success';
            $responseMessage = 'Updated successfully.';

        }else{
            $responseStatus = 'error';
            $responseMessage = 'Something went wrong, please try again.';
       
        }

        //$add = CompanyBrand::create(['name' => $request->input('name')]);
    
        return redirect()->route('services.index')
                        ->with($responseStatus, $responseMessage);
			
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Service $service)
    {
        //
    }
}
