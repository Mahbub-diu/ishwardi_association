<?php

namespace App\Http\Controllers;

use App\Models\OngoingActivityServiceCoverArea;
use App\Http\Requests\StoreOngoingActivityServiceCoverAreaRequest;
use App\Http\Requests\UpdateOngoingActivityServiceCoverAreaRequest;

class OngoingActivityServiceCoverAreaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreOngoingActivityServiceCoverAreaRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(OngoingActivityServiceCoverArea $ongoingActivityServiceCoverArea)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(OngoingActivityServiceCoverArea $ongoingActivityServiceCoverArea)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateOngoingActivityServiceCoverAreaRequest $request, OngoingActivityServiceCoverArea $ongoingActivityServiceCoverArea)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(OngoingActivityServiceCoverArea $ongoingActivityServiceCoverArea)
    {
        //
    }
}
