<?php

namespace App\Http\Controllers;

use App\Models\CoreTeam;
use App\Http\Requests\StoreCoreTeamRequest;
use App\Http\Requests\UpdateCoreTeamRequest;
use Illuminate\Http\Request;
use Auth;

Use Image;

class CoreTeamController extends Controller
{
    
	function __construct()
    {
         $this->middleware('permission:acore-team-list|core-team-create|core-team-edit|core-team-delete', ['only' => ['index','store']]);
         $this->middleware('permission:core-team-create', ['only' => ['create','store']]);
         $this->middleware('permission:core-team-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:core-team-delete', ['only' => ['destroy']]);
    }
	
	/**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $data = CoreTeam::orderBy('id','DESC')->paginate(10);
		
		
		if ( !empty($request->name) ){
			
			$data = CoreTeam::where('name', $request->name)->orderBy('id','DESC')->paginate(10);
		
		}else{
			
			$data = CoreTeam::orderBy('id','DESC')->paginate(10);
			
		}
        if($request->ajax()){
			
			return view('backend.core-teams.index-pagination',['data'=>$data]); 
       
        }
			
		
        return view('backend.core-teams.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
		$memberType = ['1' => 'Top Managements', '2' => 'Core Team Members', '3' => 'Advisors Panel'];
        //dd($memberType);
		return view('backend.core-teams.create', compact('memberType') );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'designation' => 'required',
            'photo' => 'required|mimes:jpeg,png,jpg,webp|max:2048',
            'member_type' => 'required',
			]);
    
        $input = $request->all();
		
		
		
		if ( !empty($input['photo']) ) {
            
            $imagePath = $input['photo'];
			
            $imageName = 'clientLogo_'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['photo']->storeAs('core-teams', $imageName, 'public');
			
            $input['photo'] = $imageName;
      
         
        }
        CoreTeam::create($input);
		
        return redirect()->route('core-teams.index')
                        ->with('success','Data added successfully');
						
	}

    /**
     * Display the specified resource.
     */
    public function show(CoreTeam $coreTeam)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CoreTeam $coreTeam)
    {
		$memberType = ['1' => 'Top Managements', '2' => 'Core Team Members', '3' => 'Advisors Panel'];
       
        return view('backend.core-teams.edit',compact('coreTeam', 'memberType'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CoreTeam $coreTeam, Request $request)
    {
        $input = $request->all();
        
        $this->validate($request, [
            'name' => 'required',
            'designation' => 'required',
            //'photo' => 'required|mimes:jpeg,png,jpg,webp|max:2048',
			'member_type' => 'required',
			]);

       
        $input = $request->all();
        $input['modified_user_id'] = !empty(Auth::user()->id) ? Auth::user()->id : 0;
        $input['updated_at'] = date("Y-m-d h:i:sa");;

		if ( !empty($input['photo']) ) {
            
            $imagePath = $input['photo'];
			
            $imageName = 'clientLogo_'.date('Ymdhis_').$imagePath->getClientOriginalName();
           
            $path = $input['photo']->storeAs('core-teams', $imageName, 'public');
         
            $input['photo'] = $imageName;
      
			if( !empty($coreTeam->photo) ){


                if( file_exists('storage/app/public/core-teams/'.$coreTeam->photo) ){
                
                    unlink('storage/app/public/core-teams/'.$coreTeam->photo);
                
                }
           }
        }
		
       

        $data = CoreTeam::find( $coreTeam->id );
        
        if( $data->update($input) ) {
            $responseStatus = 'success';
            $responseMessage = 'Updated successfully.';

        }else{
            $responseStatus = 'error';
            $responseMessage = 'Something went wrong, please try again.';
       
        }

        //$add = CompanyBrand::create(['name' => $request->input('name')]);
    
        return redirect()->route('core-teams.index')
                        ->with($responseStatus, $responseMessage);
						

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CoreTeam $coreTeam)
    {
		//dd($coreTeam->id);
		if( file_exists('storage/app/public/core-teams/'.$coreTeam->photo) ){
                
			unlink('storage/app/public/core-teams/'.$coreTeam->photo);
		
		}
		
        CoreTeam::find($coreTeam->id)->delete();

        return response()->json(['success'=>'Data Deleted Successfully!']);
    }
}
